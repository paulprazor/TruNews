<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'Email',
	'description' => '',
	'version'     => '2.1.0',
	'namespace'   => 'EllisLab\Addons\Email',
	'settings_exist' => FALSE,
);
