<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => 'https://ellislab.com/',
	'name'           => 'Comment',
	'description'    => '',
	'version'        => '2.3.2',
	'namespace'      => 'EllisLab\Addons\Comment',
	'settings_exist' => TRUE,
	'built_in'       => TRUE
);