<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => 'https://ellislab.com/',
	'name'           => 'Select Dropdown',
	'description'    => '',
	'version'        => '1.0.0',
	'namespace'      => 'EllisLab\Addons\SelectDropdown',
	'settings_exist' => FALSE,
	'built_in'       => TRUE,
	'fieldtypes'     => array(
		'select' => array(
			'compatibility' => 'list'
		)
	)
);

// EOF
