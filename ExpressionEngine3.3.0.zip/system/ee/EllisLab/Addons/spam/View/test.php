<p>Overall accuracy: <?=$accuracy?></p>
<p>False Positives: <?=$positives?></p>
<p>False Negatives: <?=$negatives?></p>
<p>Time: <?=$time?></p>
<p>Memory: <?=$memory?></p>
<p>Memory/Record: <?=$memory_per?></p>
<p>Records: <?=$total?></p>
<p>Time/Record: <?=$per?></p>
