<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'Emoticon',
	'description' => '',
	'version'     => '2.0.0',
	'namespace'   => 'EllisLab\Addons\Emoticon',
	'settings_exist' => FALSE,
);
