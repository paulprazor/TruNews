<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => 'https://ellislab.com/',
	'name'           => 'Jquery',
	'description'    => '',
	'version'        => '1.0.0',
	'namespace'      => 'EllisLab\Addons\Jquery',
	'settings_exist' => FALSE,
	'docs_url'       => 'https://docs.expressionengine.com/latest/add-ons/jquery/index.html',
	'built_in'       => FALSE
);
