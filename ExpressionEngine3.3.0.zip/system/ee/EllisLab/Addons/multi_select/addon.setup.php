<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => 'https://ellislab.com/',
	'name'           => 'Multi Select',
	'description'    => '',
	'version'        => '1.0.0',
	'namespace'      => 'EllisLab\Addons\MultiSelect',
	'settings_exist' => FALSE,
	'built_in'       => TRUE,
	'fieldtypes'     => array(
		'multi_select' => array(
			'compatibility' => 'list'
		)
	)
);