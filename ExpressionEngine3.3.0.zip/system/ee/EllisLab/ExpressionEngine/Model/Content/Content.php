<?php

namespace EllisLab\ExpressionEngine\Model\Content;

interface Content {}