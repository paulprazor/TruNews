<?php

namespace EllisLab\ExpressionEngine\Library\Parser\Conditional\Exception;

class ParserException extends ConditionalException {}