<?php

namespace EllisLab\ExpressionEngine\Library\Parser\Conditional\Exception;

use Exception;

class ConditionalException extends Exception {}